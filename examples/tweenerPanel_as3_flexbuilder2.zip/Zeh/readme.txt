TweenerPanel example - Tweener with Flex and Flex Builder

By Igor Costa, small changes by Zeh Fernando

To edit/recompile it, open Flex Builder, run the "File" > "Import..." menu,
option "Existing projects into workspace", leave "Select root directory"
selected and click on "Browse", and pick the directory you extracted these
files into. When the "TweenerPanel" option gets listed on the "Projects"
list, click on "Finish" and you're set.