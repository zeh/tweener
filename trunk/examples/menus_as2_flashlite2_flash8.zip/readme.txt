menus_as2_flashlite2_flash8.fla
===============================

This file is an example of Tweener applied on a Flash Lite 2 project.

A list with 9 icons is presented on screen. The first icon is selected by default. Use the LEFT and RIGHT keys to select the previous or next icon. Also, several different menu 'drawing methods' are available. Use the DOWN, ENTER/SELECT, or LEFT SOFTKEY keys to switch to the next menu type. Use the UP key to go back to the previous menu type. The RIGHT SOFTKEY key quits the movie.

The number on the top right corner of the screen is the current movie FPS. The movie was build at 30fps, but of course performance will vary depending on the mobile device being used.

---

This was created on Flash 8. Please notice that, because this file is meant to be played on Flash Lite 2 devices, it's recommended that you install the Flash Lite updates provided for the Flash IDE, and the Flash Lite device profiles available, before you attempt to open it on your Flash IDE. All files can be found on Adobe's website free of charge. You can still open and compile the project if you don't have such updates, but you will need to change the publishing properties to target the Flash Player version 7 of above, instead of Flash lite 2.

Here's some important thing: this example was built for a course I was teaching, so they're not meant exclusively as a Tweener example. Instead, it shows how Flash can be used to create different types of menu interfaces without too much effort, as it was build in just a few hours.

The interesting part is that, while it uses Tweener on all the animation, the code that actually calls Tweener is very, very small. There are only two lines that create tweens - one when it tries to scroll to another icon, and the other when it tries to change to the next menu type.

While this can be hard to swallow for people that expect tweening extensions to be simple _x/_y updating machines, it's actually a good example of how Tweener works *with* existing frameworks and engines, instead of doing all low-level visual updates altogether. In this case, all icons have their position updated on screen based on a set of parameters - which is the currently selected icon, which is that icon position in relation to the currently selected one, which is the currently selected 'drawing' function. What Tweener does - instead of trying to do crazy _x/_y updates to reproduce circular or other less common movement patterns - is that it simply works on top of the position updating engine, by telling the redraw() function to slowly move from one selected icon to another, or from one menu drawing method to another (by combining the icon property values).

The main point, I believe, is that there are many different ways of controling interface elements. You don't always tell some element to go from x1 to x2. Sometimes, instead, you tell some property to go from value1 to value2, and while it does that, it automatically updates the x of whatever element it's tied to, setting the correct value. This is as smooth as any other animation, and has the important point that the GUI elements aren't just floating boxes detached from everything else; they're rather tied to some other property value, and that's this other property that is tweened instead.

Obviously, this is not to say "Oh, Tweener is not good enough to tween these icons because it's too complex". No tweening or transition extension would be good enough to tween those icons, because their position is based on a custom set of rules and trying to update them directly would make hideous, direct animation transitions, with linear value updates at best. When you have this new, separate layer that tell how certain interface elements must behave, you should use whichever transition or tweening extension you have on the engine itself, not on the objects directly. For some kinds of complex (or maybe 'well built') interface elements, this is a key point.

Also, this menu engine is a moderately simple one and it has some issues. The depth calculation is one of them. While it works most of the time, it's done very poorly and can create some odd depth issues. If you intend on using this menu code somewhere else, be sure to write some better depth management code.


- Zeh Fernando
